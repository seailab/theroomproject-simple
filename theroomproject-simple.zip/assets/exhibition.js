'use strict';
(()=>{
 const toggle=document.querySelector('.menu-toggle'),panel=document.querySelector('#mobile-navigation');
 let menuOpen=false;
 const setMenu=open=>{menuOpen=open;panel.hidden=!open;panel.inert=!open;toggle.setAttribute('aria-expanded',String(open));toggle.querySelector('span').textContent=open?'Close':'Menu';document.body.classList.toggle('menu-open',open);document.querySelector('main').inert=open;document.querySelector('footer').inert=open;document.querySelector('.quick-contact').inert=open;if(!open)toggle.focus({preventScroll:true})};
 toggle?.addEventListener('click',()=>setMenu(!menuOpen));
 panel?.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>setMenu(false)));
 document.addEventListener('keydown',e=>{if(!menuOpen)return;if(e.key==='Escape'){e.preventDefault();setMenu(false)}if(e.key==='Tab'){const nodes=[toggle,...panel.querySelectorAll('a')],first=nodes[0],last=nodes.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus()}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus()}}});
 matchMedia('(min-width: 901px)').addEventListener('change',e=>{if(e.matches&&menuOpen)setMenu(false)});
 // Full-size images are optional. Both before and after remain visible without a gesture.
 const viewer=document.querySelector('#room-viewer');let imageOpener;
 document.querySelectorAll('[data-room-image]').forEach(button=>button.addEventListener('click',()=>{imageOpener=button;viewer.querySelector('img').src=button.dataset.roomImage;viewer.querySelector('img').alt=button.dataset.roomAlt;viewer.querySelector('h2').textContent=button.dataset.roomTitle;viewer.showModal();document.body.classList.add('viewer-open')}));
 viewer?.querySelector('.viewer-close').addEventListener('click',()=>viewer.close());
 viewer?.addEventListener('click',e=>{if(e.target===viewer){const r=viewer.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)viewer.close()}});
 viewer?.addEventListener('close',()=>{document.body.classList.remove('viewer-open');imageOpener?.focus({preventScroll:true})});
 // No tracking libraries or third-party embeds are needed for the exhibition.
 // The footer already contains both contact routes; avoid covering its links.
 if('IntersectionObserver'in window)new IntersectionObserver(entries=>{document.querySelector('.quick-contact').classList.toggle('footer-reached',entries[0].isIntersecting)}).observe(document.querySelector('.site-footer'));
 // Anchor navigation stays accurate when reaching Packages from another page.
 const updatePackages=()=>{if(location.pathname.replace(/\/$/,'')!=="/theroomproject-simple")return;document.querySelectorAll('.desktop-nav a').forEach(a=>{if(a.getAttribute('href')===(location.hash==='#packages'?"/theroomproject-simple/#packages":"/theroomproject-simple/"))a.setAttribute('aria-current','page');else a.removeAttribute('aria-current')})};
 window.addEventListener('hashchange',updatePackages);updatePackages();
})();
