"use strict";
// Never simulate a successful submission or transmit personal details on Pages.
document.addEventListener('submit',event=>{
 const form=event.target;if(!form.matches('[data-preview-enquiry]'))return;
 event.preventDefault();event.stopImmediatePropagation();
 const status=form.querySelector('.form-status');status.textContent='This is a website preview. No enquiry was sent or saved. Please use WhatsApp or email to contact us directly.';status.classList.remove('error');status.setAttribute('tabindex','-1');status.focus();
},true);
